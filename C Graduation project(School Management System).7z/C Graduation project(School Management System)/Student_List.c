#include <stdio.h>
#include "Student_List.h"
#include "malloc.h"
#include "ctype.h"
#include <string.h>
#include "Student_List_Priv.h"


void Student_voidInit(void)
{
/*  tsStudentList->NextNode=&hossam1;
    hossam1.LastNode=tsStudentList;
    hossam1.NextNode=&hossam2;
    hossam2.LastNode=&hossam1;
    hossam2.NextNode=&hossam3;
    hossam3.LastNode=&hossam2;
    hossam3.NextNode=&hossam4;
    hossam4.LastNode=&hossam3;
    hossam4.NextNode=tsStudentLastNode;
   tsStudentLastNode->LastNode=&hossam4;
   tsStudentLastNode->NodeNumber=4;

   */
   tsStudentLastNode->NodeNumber=1;
   tsStudentList->NextNode=tsStudentLastNode;
   tsStudentLastNode->LastNode=tsStudentList;
}
void Student_voidDeleteStudent(void)
{
    if(tsStudentList->NextNode!=tsStudentLastNode)
    {
     char u8StudentProperty[1]={0};
     char pu8PropertyValueLoc[1000]={0};
     tstructStudentDetailsNode *iterator ;
     puts("please enter student property(NAME:0,ADDRESS:1,ID:2,BIRTHDAY:3,BIRTHMONTH:4,BIRTHYEAR:5,PHONE:6,COMPUTERSCIENCESCORE:7): ");
     gets(u8StudentProperty);
     puts("please enter student property value: ");
     gets(pu8PropertyValueLoc);
    for(iterator=tsStudentList->NextNode;iterator!=tsStudentLastNode;iterator=iterator->NextNode)
    {
        if(*u8StudentProperty==NAME)
        {

            if(!strcmp(iterator->structStudentDetails.au8Name,pu8PropertyValueLoc))
            {
                voidDeleteStudent(iterator);
            }
        }
        else if(*u8StudentProperty==ID)
        {
            if(!strcmp(iterator->structStudentDetails.au8ID,pu8PropertyValueLoc))
            {
                 voidDeleteStudent(iterator);
            }
        }
        else if(*u8StudentProperty==ADDRESS)
        {
            if(!strcmp(iterator->structStudentDetails.au8Address,pu8PropertyValueLoc))
            {
                voidDeleteStudent(iterator);
            }
        }
        else if(*u8StudentProperty==BIRTH_DAY)
        {
            if(!strcmp(iterator->structStudentDetails.au8BirthDay,pu8PropertyValueLoc))
            {
                 voidDeleteStudent(iterator);
            }
        }
        else if(*u8StudentProperty==BIRTH_MONTH)
        {
            if(!strcmp(iterator->structStudentDetails.au8BirthMonth,pu8PropertyValueLoc))
            {
                voidDeleteStudent(iterator);
            }
        }
        else if(*u8StudentProperty==BIRTH_YEAR)
        {
            if(!strcmp(iterator->structStudentDetails.au8BirthYear,pu8PropertyValueLoc))
            {
                 voidDeleteStudent(iterator);
            }
        }
        else if(*u8StudentProperty==PHONE_NUMBER)
        {
            if(!strcmp(iterator->structStudentDetails.au8Phone,pu8PropertyValueLoc))
            {
                 voidDeleteStudent(iterator);
            }
        }
        else if(*u8StudentProperty==COMPUTER_SCIENCE_SCORE)
        {
            if(!strcmp(iterator->structStudentDetails.au8ComputerScienceScore,pu8PropertyValueLoc))
            {
                 voidDeleteStudent(iterator);
            }
        }
        else
        {
        }

    }
    }
    else
    {
        puts("The List is Empty");
    }
}
void Student_voidNewStudent(void)
{
    int iterator=0;
    char temp[1000]={0};
    voidCreateStudentNode();

    while(1)
    {

    printf("Enter The New Student Name : ");
    gets(temp);

    if(strlen(temp)>50)
    {
       strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8Name,temp,49);
    }
    else
    {
        strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8Name,temp);
    }
    if(check_isalpha(tsStudentLastNode->LastNode->structStudentDetails.au8Name))
    {
       break;
    }

        puts("Entered Name Is Not Alphabetic ");

    }

     while(1)
    {
    printf("Enter The New Student ID: ");
    gets(temp);
    if(strlen(temp)>50)
    {
       strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8ID,temp,49);
    }
    else
    {
        strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8ID,temp);
    }

    if(check_isalnum(tsStudentLastNode->LastNode->structStudentDetails.au8ID))
    {
        break;
    }
    puts("Entered ID Is Not Alphanumeric ");
    }
    printf("Enter The New Student Address: ");
    gets(temp);
    if(strlen(temp)>100)
    {
       strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8Address,temp,99);
    }
    else
    {
        strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8Address,temp);
    }

    while(1)
    {
    printf("Enter The New Student Birth Year : ");
    gets(temp);

    if(check_isdigit(temp))
    {
        if(strlen(temp)>5)
            {
               strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthYear,temp,4);
            }
            else
            {
                strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthYear,temp);
            }
        break;

    }
    puts("Entered Birth Year Is Not digits ");
    }
    while(1)
    {
    printf("Enter The New Student Birth Month : ");
    gets(temp);
    if(check_isdigit(temp))
    {
        if(strtol(temp,'\0',10)>=1&&strtol(temp,'\0',10)<=12)
        {
          if(strlen(temp)>3)
            {
               strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthMonth,temp,2);
            }
            else
            {

                strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthMonth,temp);
            }
          break;
        }
     else
     {
        puts("Entered Birth Month Is Not Acceptable ");
     }


    }
    else
    {
        puts("Entered Birth Month Is Not digits ");
    }

    }

     while(1)
    {
    printf("Enter The New Student Birth Day : ");
    gets(temp);


    if(check_isdigit(temp))
    {

        if(check_number_of_Days()&&strtol(temp,'\0',10)>=1)
        {
          if(strlen(temp)>3)
            {
               strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthDay,temp,2);
            }
            else
            {

                strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthDay,temp);
            }
          break;
        }
        else
        {
           puts("Entered Birth Day Is Not Acceptable ");
        }


    }
    else
    {
      puts("Entered Birth Day Is Not digits ");
    }


    }


    while(1)
    {
    printf("Enter The New Student Phone Number : ");
    gets(temp);
    if(strlen(temp)>20)
    {
       strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8Phone,temp,19);
    }
    else
    {
        strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8Phone,temp);
    }
    if(check_isdigit(tsStudentLastNode->LastNode->structStudentDetails.au8Phone))
    {
        break;

    }
    puts("Entered Address Is Not digits ");
    }
    while(1)
    {
    printf("Enter The New Student Computer Science Score : ");
    gets(temp);
    if(strlen(temp)>4)
    {
       strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8ComputerScienceScore,temp,3);
    }
    else
    {
        strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8ComputerScienceScore,temp);
    }
    if(check_isdigit(tsStudentLastNode->LastNode->structStudentDetails.au8ComputerScienceScore))
    {
        break;

    }
    puts("Entered Address Is Not digits ");
    }
}
void Student_voidStudentList(void)
{
   if(tsStudentList->NextNode==tsStudentLastNode)
   {
     puts("The List is Empty");
   }
   else
   {
    tstructStudentDetailsNode *iterator;
    for(iterator = tsStudentList->NextNode;iterator!=tsStudentLastNode;iterator=iterator->NextNode)
    {
      printing_student_data(iterator);
    }
   }

}
void Student_voidMainMenu(void)
{

printf("\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
***********************To Add New  Student,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,(Press : '0')***********************\n\
***********************To Delete A Student...............................(Press : '1')***********************\n\
***********************To View All Students~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~(press : '2')***********************\n\
***********************To Edit A Student---------------------------------(press : '3')***********************\n\
***********************To Rank The Students==============================(press : '4')***********************\n\
***********************To Edit All Students's Computer Science Scores\"\"\"\"(Press : '5')***********************\n\
***********************To Exit>->->->->->->->->->->->->->->->->->->->->->(Press : '6')***********************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
*************************************************************************************************************\n\
Your Choice-->> ");

}
void Student_voidStudentEdit(void)
{
    char u8StudentProperty[1]={0};
    char u8ContinueState[1]={0};
    char temp[1000]={0};

     printf("Please Select a Student Property To Find The Student(NAME:0\n\
                                                                 ,ADDRESS:1\n\
                                                                 ,ID:2\n\
                                                                 ,BIRTH DAY:3\n\
                                                                 ,BIRTH MONTH:4\n\
                                                                 ,BIRTH YEAR:5\n\
                                                                 ,PHONE NUMBER:6\n\
                                                                 ,COMPUTER SCIENCE SCORE:7\n\
                                                                 ,STUDENT NUMBER:8): ");
     gets(u8StudentProperty);
     printf("Please Enter Student Property Value : ");
     gets(temp);
     tstructStudentDetailsNode * selected_student = pstrFindStudentByProperty(u8StudentProperty,temp);
     if(selected_student!=tsStudentLastNode)
     {
         printing_student_data(selected_student);
         printf("this is the founded student press 1 to continue or 0 to exit : ");
         gets(u8ContinueState);
         if(*u8ContinueState=='1')
            {
                 printf("Please Select a Student Property To Find The Student(NAME:0\n\
                                                                 ,ADDRESS:1\n\
                                                                 ,ID:2\n\
                                                                 ,BIRTH DAY:3\n\
                                                                 ,BIRTH MONTH:4\n\
                                                                 ,BIRTH YEAR:5\n\
                                                                 ,PHONE NUMBER:6\n\
                                                                 ,COMPUTER SCIENCE SCORE:7): ");
                 gets(u8StudentProperty);
                 if(*u8StudentProperty==NAME)
                    {
                                while(1)
                                {

                                printf("Enter The Student's New Name : ");
                                gets(temp);

                                if(strlen(temp)>50)
                                    {
                                       strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8Name,temp,49);
                                    }
                                else
                                    {
                                        strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8Name,temp);
                                    }
                                if(check_isalpha(tsStudentLastNode->LastNode->structStudentDetails.au8Name))
                                    {
                                       break;
                                    }

                                    puts("Entered Name Is Not Alphabetic ");

                                }

                    }
                    else if(*u8StudentProperty==ID)
                    {
                             while(1)
                                {
                                printf("Enter The Student's New ID : ");
                                gets(temp);
                                if(strlen(temp)>50)
                                    {
                                       strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8ID,temp,49);
                                    }
                                else
                                    {
                                        strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8ID,temp);
                                    }

                                if(check_isalnum(tsStudentLastNode->LastNode->structStudentDetails.au8ID))
                                    {
                                        break;
                                    }
                                puts("Entered ID Is Not Alphanumeric ");
                                }
                    }
                    else if(*u8StudentProperty==ADDRESS)
                    {
                                printf("Enter The Student's New Address: ");
                                gets(temp);

                                printf("%d",strlen(temp));
                                if(strlen(temp)>100)
                                    {
                                       strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8Address,temp,99);
                                    }
                                else
                                    {
                                        strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8Address,temp);
                                    }

                    }
                    else if(*u8StudentProperty==BIRTH_DAY)
                    {
                              while(1)
                                {
                                    printf("Enter The Student's New Birth Day : ");
                                    gets(temp);


                                    if(check_isdigit(temp))
                                    {

                                        if(check_number_of_Days()&&strtol(temp,'\0',10)>=1)
                                        {
                                          if(strlen(temp)>3)
                                            {
                                               strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthDay,temp,2);
                                            }
                                            else
                                            {

                                                strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthDay,temp);
                                            }
                                          break;
                                        }
                                        else
                                        {
                                           puts("Entered Birth Day Is Not Acceptable ");
                                        }


                                    }
                                    else
                                    {
                                      puts("Entered Birth Day Is Not digits ");
                                    }


                                }

                    }
                    else if(*u8StudentProperty==BIRTH_MONTH)
                    {
                        while(1)
                                {
                                printf("Enter The Student's New Birth Month : ");
                                gets(temp);
                                if(check_isdigit(temp))
                                {
                                    if(strtol(temp,'\0',10)>=1&&strtol(temp,'\0',10)<=12)
                                         {
                                          if(strlen(temp)>3)
                                                {
                                                   strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthMonth,temp,2);
                                                }
                                            else
                                                {

                                                    strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthMonth,temp);
                                                }
                                          break;
                                         }
                                    else
                                         {
                                            puts("Entered Birth Month Is Not Acceptable ");
                                         }


                                }
                                else
                                {
                                    puts("Entered Birth Month Is Not digits ");
                                }

                                }
                    }
                    else if(*u8StudentProperty==BIRTH_YEAR)
                    {
                           while(1)
                                {
                                    printf("Enter The Student's New Birth Year : ");
                                    gets(temp);

                                    if(check_isdigit(tsStudentLastNode->LastNode->structStudentDetails.au8BirthYear))
                                    {
                                        if(strlen(temp)>5)
                                            {
                                               strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthYear,temp,4);
                                            }

                                        else
                                            {
                                                strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8BirthYear,temp);
                                            }
                                        break;

                                }
                                puts("Entered Birth Year Is Not digits ");
                                }
                    }
                    else if(*u8StudentProperty==PHONE_NUMBER)
                    {
                            while(1)
                                {
                                    printf("Enter The Student's New Phone Number : ");
                                    gets(temp);
                                    if(strlen(temp)>20)
                                        {
                                           strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8Phone,temp,19);
                                        }
                                    else
                                        {
                                            strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8Phone,temp);
                                        }
                                    if(check_isdigit(tsStudentLastNode->LastNode->structStudentDetails.au8Phone))
                                        {
                                            break;

                                        }
                                    puts("Entered Address Is Not digits ");
                                }
                    }
                    else if(*u8StudentProperty==COMPUTER_SCIENCE_SCORE)
                    {
                                     while(1)
                                        {
                                        printf("Enter The Student's New Computer Science Score : ");
                                        gets(temp);
                                        if(strlen(temp)>4)
                                            {
                                               strncpy(tsStudentLastNode->LastNode->structStudentDetails.au8ComputerScienceScore,temp,3);
                                            }
                                        else
                                            {
                                                strcpy(tsStudentLastNode->LastNode->structStudentDetails.au8ComputerScienceScore,temp);
                                            }
                                        if(check_isdigit(tsStudentLastNode->LastNode->structStudentDetails.au8ComputerScienceScore))
                                            {
                                                break;
                                            }
                                        puts("Entered Address Is Not digits ");
                                        }

                    }
                    else if(*u8StudentProperty==STUDENT_NUMBER)
                    {
                                     while(1)
                                        {
                                        printf("Enter The Student's New Student Number : ");
                                        gets(temp);
                                        if(strlen(temp)>4)
                                            {
                                               strncpy(tsStudentLastNode->LastNode->NodeNumber,temp,3);
                                            }
                                        else
                                            {
                                                strcpy(tsStudentLastNode->LastNode->NodeNumber,temp);
                                            }
                                        if(check_isdigit(tsStudentLastNode->LastNode->NodeNumber))
                                            {
                                                break;
                                            }
                                        puts("Entered Address Is Not digits ");
                                        }

                    }
                    else
                    {
                         puts("there are no student with this property");
                    }
            }
             else
             {

             }
     }
     else
     {
         puts("there are no student with this property");
     }
}
void Student_voidRankStudent(void)
{
    int iterator;
    tstructStudentDetailsNode *iterator1;
    tstructStudentDetailsNode *Temp_Node=tsStudentLastNode;
    for(iterator=0;iterator<Temp_Node->NodeNumber;iterator++)
    {
        for(iterator1=tsStudentList->NextNode;iterator1!=Temp_Node->LastNode;iterator1=iterator1->NextNode)
            {

                if(strtol(iterator1->structStudentDetails.au8ComputerScienceScore,'\0',10)<strtol(iterator1->NextNode->structStudentDetails.au8ComputerScienceScore,'\0',10))
                    {
                       voidSwapStudentNodes(iterator1);
                       iterator1=iterator1->LastNode;
                    }

            }
             Temp_Node=Temp_Node->LastNode;
    }
}
void Student_voidStudentScore(void)
{
    tstructStudentDetailsNode * iterator;
    char temp[1000]={0};
    for(iterator=tsStudentList->NextNode;iterator!=tsStudentLastNode;iterator=iterator->NextNode)
    {

        while(1)
         {
         printing_student_data(iterator);
         printf("Enter %s's New Computer Science Score : ",iterator->structStudentDetails.au8Name);
         gets(temp);

         if(check_isdigit(temp))
             {
            if(strlen(temp)>4)
             {
                strncpy(iterator->structStudentDetails.au8ComputerScienceScore,temp,3);
             }
         else
             {
                 strcpy(iterator->structStudentDetails.au8ComputerScienceScore,temp);
             }
                 break;
             }
         puts("Entered Address Is Not digits ");
         }
    }
}




