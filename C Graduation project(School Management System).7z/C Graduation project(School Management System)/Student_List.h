



#ifndef STUDENT_LIST_H
#define STUDENT_LIST_H



void Student_voidInit(void);
void Student_voidNewStudent(void);
void Student_voidDeleteStudent(void);
void Student_voidStudentList(void);
void Student_voidMainMenu(void);
void Student_voidStudentEdit(void);
void Student_voidRankStudent(void);
void Student_voidStudentScore(void);





#endif
