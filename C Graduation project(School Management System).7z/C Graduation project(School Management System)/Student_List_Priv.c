#include <stdio.h>
#include "malloc.h"
#include "ctype.h"
#include <string.h>
#include "Student_List_Priv.h"

tstructStudentEmptyNode   StudentEmptyStartNode={0};
tstructStudentEmptyNode   StudentEmptyEndNode={0};
tstructStudentEmptyNode * tsStudentList=&StudentEmptyStartNode;
tstructStudentEmptyNode * tsStudentLastNode=&StudentEmptyEndNode;
/*tstructStudentDetailsNode hossam1={0,0,0,{"hossam1","1234","4 mohamed hashim street/ almataria/ cairo","1992","11","1","01025508950","120"}};
//tstructStudentDetailsNode hossam2={1,0,0,{"hossam2","1234","4 mohamed hashim street/ almataria/ cairo","1992","11","1","01025508950","5"}};
//tstructStudentDetailsNode hossam3={2,0,0,{"hossam3","1234","4 mohamed hashim street/ almataria/ cairo","1992","11","1","01025508950","10"}};
//tstructStudentDetailsNode hossam4={3,0,0,{"hossam4","1234","4 mohamed hashim street/ almataria/ cairo","1992","11","1","01025508950","4"}};
*/


void voidSwapStudentNodes(tstructStudentDetailsNode* Node)
{
    Node->NextNode->LastNode=Node->LastNode;
    Node->LastNode->NextNode=Node->NextNode;
    Node->NextNode=Node->NextNode->NextNode;
    Node->NextNode->LastNode=Node;
    Node->LastNode->NextNode->NextNode=Node;
    Node->LastNode=Node->LastNode->NextNode;
    Node->NodeNumber=Node->LastNode->NodeNumber;
    Node->LastNode->NodeNumber--;
}

tstructStudentDetailsNode * pstrFindStudentByNode(int NodeNumber)
{
    tstructStudentDetailsNode *iterator ;
    for(iterator = tsStudentList->NextNode;iterator!=tsStudentLastNode;iterator=iterator->NextNode)
    {
        if(iterator->NodeNumber==NodeNumber)
        {
            break;
        }
    }
    return iterator;
}
tstructStudentDetailsNode * pstrFindStudentByProperty(char* pu8StudentPropertyLoc,char * pu8PropertyValueLoc)
{
    tstructStudentDetailsNode *iterator ;
    for(iterator = tsStudentList->NextNode;iterator!=tsStudentLastNode;iterator=iterator->NextNode)
    {
        if(*pu8StudentPropertyLoc==NAME)
        {
            if(!strcmp(iterator->structStudentDetails.au8Name,pu8PropertyValueLoc))
            {
                break;
            }
        }
        else if(*pu8StudentPropertyLoc==ID)
        {
            if(!strcmp(iterator->structStudentDetails.au8ID,pu8PropertyValueLoc))
            {
                break;
            }
        }
        else if(*pu8StudentPropertyLoc==ADDRESS)
        {
            if(!strcmp(iterator->structStudentDetails.au8Address,pu8PropertyValueLoc))
            {
                break;
            }
        }
        else if(*pu8StudentPropertyLoc==BIRTH_DAY)
        {
            if(!strcmp(iterator->structStudentDetails.au8BirthDay,pu8PropertyValueLoc))
            {
                break;
            }
        }
        else if(*pu8StudentPropertyLoc==BIRTH_MONTH)
        {
            if(!strcmp(iterator->structStudentDetails.au8BirthMonth,pu8PropertyValueLoc))
            {
                break;
            }
        }
        else if(*pu8StudentPropertyLoc==BIRTH_YEAR)
        {
            if(!strcmp(iterator->structStudentDetails.au8BirthYear,pu8PropertyValueLoc))
            {
                break;
            }
        }
        else if(*pu8StudentPropertyLoc==PHONE_NUMBER)
        {
            if(!strcmp(iterator->structStudentDetails.au8Phone,pu8PropertyValueLoc))
            {
                break;
            }
        }
        else if(*pu8StudentPropertyLoc==COMPUTER_SCIENCE_SCORE)
        {
            if(!strcmp(iterator->structStudentDetails.au8ComputerScienceScore,pu8PropertyValueLoc))
            {
                break;
            }
        }
        else if(*pu8StudentPropertyLoc==STUDENT_NUMBER)
        {
            if(!strcmp(iterator->NodeNumber,pu8PropertyValueLoc))
            {
                break;
            }
        }
    }
    return iterator;
}

void printing_student_data(tstructStudentDetailsNode *iterator)
{
   printf("<<=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=>>\n");
         printf("Student (%d) \n",iterator->NodeNumber);
         printf("Name----------------->: %s\n",iterator->structStudentDetails.au8Name);
         printf("ID------------------->: %s\n",iterator->structStudentDetails.au8ID);
         printf("Address-------------->: %s\n",iterator->structStudentDetails.au8Address);
         printf("Birth Date----------->: %s/%s/%s\n",iterator->structStudentDetails.au8BirthDay
                                                    ,iterator->structStudentDetails.au8BirthMonth
                                                    ,iterator->structStudentDetails.au8BirthYear);
         printf("Phone---------------->: %s\n",iterator->structStudentDetails.au8Phone);
         printf("Computer Science Score: %s\n",iterator->structStudentDetails.au8ComputerScienceScore);
   printf("<<=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=>>\n\n");
}
void voidDeleteStudent(tstructStudentDetailsNode * structStudentDetailsNodeLoc)
{
        structStudentDetailsNodeLoc->LastNode->NextNode=structStudentDetailsNodeLoc->NextNode;
        structStudentDetailsNodeLoc->NextNode->LastNode=structStudentDetailsNodeLoc->LastNode;
        printing_student_data(structStudentDetailsNodeLoc);
        structStudentDetailsNodeLoc=structStudentDetailsNodeLoc->LastNode;
        tstructStudentDetailsNode * iterator;
        for(iterator=structStudentDetailsNodeLoc;iterator!=tsStudentLastNode;iterator=iterator->NextNode)
        {
            iterator->NodeNumber--;
        }
        free(structStudentDetailsNodeLoc->NextNode);
        puts("this student is Deleted successfully");
}
void voidAddStudent(tstructStudentDetailsNode * structStudentDetailsNodeLoc,int NodeNumber)
{

        tstructStudentDetailsNode * iterator;
        for(iterator=tsStudentList;(iterator->NodeNumber>=NodeNumber)&&(iterator!=tsStudentLastNode);iterator=iterator->NextNode);
                iterator->LastNode->NextNode=structStudentDetailsNodeLoc;
                structStudentDetailsNodeLoc->LastNode=iterator->LastNode;
                structStudentDetailsNodeLoc->NextNode=iterator;
                structStudentDetailsNodeLoc->NodeNumber=NodeNumber;

}
void voidCreateStudentNode(void)
{
      tstructStudentDetailsNode*NewStudent=(tstructStudentDetailsNode*)malloc(sizeof(tstructStudentDetailsNode));
      tsStudentLastNode->LastNode->NextNode=NewStudent;
      NewStudent->LastNode=tsStudentLastNode->LastNode;
      NewStudent->NextNode=tsStudentLastNode;
      tsStudentLastNode->LastNode=NewStudent;
      NewStudent->NodeNumber=tsStudentLastNode->NodeNumber;
      tsStudentLastNode->NodeNumber++;

}
int check_isdigit(char * pu8String)
{
    int u32StateLoc=1;
    while(*pu8String!='\0')
    {
        if(!isdigit(*(pu8String)))
        {
            u32StateLoc=0;
            break;
        }
        pu8String++;
    }
   return u32StateLoc;
}
int check_isalpha(char * pu8String)
{
     int u32StateLoc=1;
    while(*pu8String!='\0')
    {

        if(!isalpha(*(pu8String))&&*pu8String!=' ')
        {
            u32StateLoc=0;
            break;
        }
        pu8String++;
    }

   return u32StateLoc;
}
int check_isalnum(char * pu8String)
{
     int u32StateLoc=1;
    while(*pu8String!='\0')
    {
        if(!isalnum(*(pu8String++)))
        {
            u32StateLoc=0;
            break;
        }
        pu8String++;
    }
   return u32StateLoc;
}
int check_number_of_Days(void)
{
    int BirthMonth=strtol(tsStudentLastNode->LastNode->structStudentDetails.au8BirthMonth,'\0',10);
    int BirthYear=strtol(tsStudentLastNode->LastNode->structStudentDetails.au8BirthYear,'\0',10);
    int BirthDay=strtol(tsStudentLastNode->LastNode->structStudentDetails.au8BirthDay,'\0',10);

    int Check=1;
    int day_value;
    if(BirthMonth==1||BirthMonth==3||BirthMonth==5||BirthMonth==7||BirthMonth==8||BirthMonth==10||BirthMonth==12)
{
     day_value=31;
}
else if(BirthMonth==4||BirthMonth==6||BirthMonth==9||BirthMonth==11)
{
     day_value=30;
}
else if(BirthMonth==2)
{
    if((((BirthYear%4))||(!(BirthYear%100)))&&((BirthYear%400)))
    {
         day_value=28;
    }
    else
    {
        day_value=29;
    }
    }
    if(BirthDay>day_value)
    {
       Check=0;
    }
    return Check;

}






