#include <stdio.h>
#include <stdlib.h>
#include "Student_List.h"
#include <string.h>
enum
{
CREATE_NEW_STUDENT='0',
DELETE_STUDENT,
SHOW_STUDENT_LIST,
EDIT_STUDENT,
RANK_STUDENT,
STUDENT_SCORE,
EXIT,
}tenuOperation;
int main()
{
puts("                     U _____ u  _        ____   U  ___ u  __  __  U _____ u      _____   U  ___ u\n\
         __        __\\| ___\"|/ |\"|    U /\"___|   \\/\"_ \\/U|' \\/ '|u\\| ___\"|/     |_ \" _|   \\/\"_ \\/\n\
         \\\"\\      /\"/ |  _|\" U | | u  \\| | u     | | | |\\| |\\/| |/ |  _|\"         | |     | | | |\n\
         /\\ \\ /\\ / /\\ | |___  \\| |/__  | |/__.-,_| |_| | | |  | |  | |___        /| |\\.-,_| |_| |\n\
        U  \\ V  V /  U|_____|  |_____|  \\____|\\_)-\\___/  |_|  |_|  |_____|      u |_|U \\_)-\\___/\n\
        .-,_\\ /\\ /_,-.<<   >>  //  \\\\  _// \\\\      \\\\   <<,-,,-.   <<   >>      _// \\\\_     \\\\\n\
         \\_)-'  '-(_/(__) (__)(_\")(\"_)(__)(__)    (__)   (./  \\.) (__) (__)    (__) (__)   (__)\n\
                                                  _____\n\
                                         ___     |_ \" _|     ___\n\
                                        |_\"_|      | |      |_\"_|\n\
                                         | |      /| |\\      | |\n\
                                       U/| |\\u   u |_|U    U/| |\\u\n\
                                    .-,_|___|_,-._// \\\\_.-,_|___|_,-.\n\
                                     \\_)-' '-(_/(__) (__)\\_)-' '-(_/\n\
                          ____      ____   _   _     U  ___ u   U  ___ u   _\n\
                         / __\"| uU /\"___| |'| |'|     \\/\"_ \\/    \\/\"_ \\/  |\"|\n\
                        <\\___ \\/ \\| | u  /| |_| |\\    | | | |    | | | |U | | u\n\
                         u___) |  | |/__ U|  _  |u.-,_| |_| |.-,_| |_| | \\| |/__\n\
                         |____/>>  \\____| |_| |_|  \\_)-\\___/  \\_)-\\___/   |_____|\n\
                          )(  (__)_// \\\\  //   \\\\       \\\\         \\\\     //  \\\\\n\
                         (__)    (__)(__)(_\") (\"_)     (__)       (__)   (_\")(\"_)\n\
          __  __      _      _   _       _       ____  U _____ u  __  __  U _____ u _   _     _____\n\
        U|' \\/ '|uU  /\"\\  u | \\ |\"|  U  /\"\\  uU /\"___|u\\| ___\"|/U|' \\/ '|u\\| ___\"|/| \\ |\"|   |_ \" _|\n\
        \\| |\\/| |/ \\/ _ \\/ <|  \\| |>  \\/ _ \\/ \\| |  _ / |  _|\"  \\| |\\/| |/ |  _|\" <|  \\| |>    | |\n\
         | |  | |  / ___ \\ U| |\\  |u  / ___ \\  | |_| |  | |___   | |  | |  | |___ U| |\\  |u   /| |\\\n\
         |_|  |_| /_/   \\_\\ |_| \\_|  /_/   \\_\\  \\____|  |_____|  |_|  |_|  |_____| |_| \\_|   u |_|U\n\
        <<,-,,-.   \\\\    >> ||   \\\\,-.\\\\    >>  _)(|_   <<   >> <<,-,,-.   <<   >> ||   \\\\,-._// \\\\_\n\
         (./  \\.) (__)  (__)(_\")  (_/(__)  (__)(__)__) (__) (__) (./  \\.) (__) (__)(_\")  (_/(__) (__)\n\
                          ____      __   __ ____     _____  U _____ u  __  __\n\
                         / __\"| u   \\ \\ / // __\"| u |_ \" _| \\| ___\"|/U|' \\/ '|u\n\
                        <\\___ \\/     \\ V /<\\___ \\/    | |    |  _|\"  \\| |\\/| |/\n\
                         u___) |    U_|\"|_uu___) |   /| |\\   | |___   | |  | |\n\
                         |____/>>     |_|  |____/>> u |_|U   |_____|  |_|  |_|\n\
                          )(  (__).-,//|(_  )(  (__)_// \\\\_  <<   >> <<,-,,-.\n\
                         (__)      \\_) (__)(__)    (__) (__)(__) (__) (./  \\.)created by Hossam Ali Abdessalam");

char enuOperationLoc[1]={0};
Student_voidInit();
while(1)
{
  Student_voidMainMenu();
  gets(enuOperationLoc);
  if(*enuOperationLoc==CREATE_NEW_STUDENT)
  {
       Student_voidNewStudent();
  }
  else if(*enuOperationLoc==DELETE_STUDENT)
  {
      Student_voidDeleteStudent();
  }
  else if(*enuOperationLoc==SHOW_STUDENT_LIST)
  {
      Student_voidStudentList();
  }
  else if(*enuOperationLoc==EDIT_STUDENT)
  {
       Student_voidStudentEdit();
  }
  else if(*enuOperationLoc==RANK_STUDENT)
  {
       Student_voidRankStudent();
  }
  else if(*enuOperationLoc==STUDENT_SCORE)
  {
       Student_voidStudentScore();
  }
  else if(*enuOperationLoc==EXIT)
  {

      return 0;
  }

}


}
