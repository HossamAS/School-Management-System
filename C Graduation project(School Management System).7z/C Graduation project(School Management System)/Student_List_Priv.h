#ifndef STUDENT_LIST_PRIV_H
#define STUDENT_LIST_PRIV_H

enum{
NAME='0',
ADDRESS,
ID,
BIRTH_DAY,
BIRTH_MONTH,
BIRTH_YEAR,
PHONE_NUMBER,
COMPUTER_SCIENCE_SCORE,
STUDENT_NUMBER
}tenuStudentProperty;

struct structStudentDetailsNode{
int NodeNumber;
struct structStudentDetailsNode *LastNode;
struct structStudentDetailsNode *NextNode;
struct {
    char au8Name[50];
    char au8BirthDay[3];
    char au8BirthMonth[3];
    char au8BirthYear[5];
    char au8ID[50];
    char au8Address[100];
    char au8Phone[20];
    char au8ComputerScienceScore[4];
       }structStudentDetails;
};

struct structStudentEmptyNode{
int NodeNumber;
struct structStudentDetailsNode *LastNode;
struct structStudentDetailsNode *NextNode;
};

typedef struct structStudentEmptyNode tstructStudentEmptyNode;
typedef struct structStudentDetailsNode tstructStudentDetailsNode;
extern tstructStudentEmptyNode  StudentEmptyStartNode;
extern tstructStudentEmptyNode  StudentEmptyEndNode;
extern tstructStudentEmptyNode * tsStudentList;
extern tstructStudentEmptyNode * tsStudentLastNode;


 void voidSwapStudentNodes(tstructStudentDetailsNode* Node);
 int check_isdigit(char * pu8String);
 int check_isalpha(char * pu8String);
 void voidCreateStudentNode(void);
 tstructStudentDetailsNode * FindStudentByNode(int NodeNumber);
 tstructStudentDetailsNode * pstrFindStudentByProperty(char* pu8StudentPropertyLoc,char * pu8PropertyValueLoc);
 void voidDeleteStudent(tstructStudentDetailsNode * structStudentDetailsNodeLoc);
 void printing_student_data(tstructStudentDetailsNode *iterator);
 int check_number_of_Days(void);
#endif // STUDENT_LIST_PRIV_H
